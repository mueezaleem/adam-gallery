ADAM'S GALLERY — WEBSITE PACKAGE

Files:
- index.html
- styles.css
- script.js

How to use:
1. Extract the ZIP.
2. Open index.html in a browser.
3. Upload all three files to the same folder on your hosting.

Editable business details:
- Business: Adam’s Gallery .Gems & jewellery.Islamabad
- Address: Adams gallery Lok Virsa museum, Garden Ave, Islamabad, 44000, Pakistan
- Phone / WhatsApp: +92 332 8936813
- Hours: Monday–Sunday, 11:00 AM–8:00 PM

Notes:
- Gallery/hero photos are editorial presentation images loaded remotely from Unsplash and can be replaced with the business's own photos.
- The Google Map is embedded using the listing coordinates.
- All service cards launch WhatsApp with a pre-filled service-specific enquiry.
- Business data reflects the Google Maps listing checked when this package was created.
