
const header = document.querySelector('.site-header');
const menuBtn = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

window.addEventListener('scroll',()=>header.classList.toggle('scrolled',window.scrollY>30),{passive:true});

menuBtn.addEventListener('click',()=>{
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded',open);
});
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

const io = new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
  });
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

const phone = '923328936813';
document.querySelectorAll('[data-service]').forEach(card=>{
  const service = card.dataset.service;
  const msg = `Hello Adam's Gallery, I'm interested in ${service}. Could you please share the price and available timings?`;
  card.href = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  card.target = '_blank';
  card.rel = 'noopener';
});
